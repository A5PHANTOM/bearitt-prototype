$(document).ready(function() {
    // Load navbar and footer dynamically
    $('#navbar-placeholder').load('navibar.html', function() {
        // Check if navbar is loaded successfully
        console.log('Navbar Loaded');

        // Mobile drawer toggle
        $(document).on('click', '#hamburger-menu', function() {
            console.log('Hamburger clicked');
            $('#mobile-drawer').toggleClass('open');
        });

        // Close drawer on close button click
        $(document).on('click', '#close-drawer', function() {
            console.log('Close button clicked');
            $('#mobile-drawer').removeClass('open');
        });

        // Handle clicks outside to close the drawer
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#mobile-drawer, #hamburger-menu').length) {
                console.log('Click outside detected');
                $('#mobile-drawer').removeClass('open');
            }
        });

        // Check links functionality in navbar
        $(document).on('click', '.navbar-links a', function() {
            console.log('Navbar link clicked:', $(this).text());
        });
    });

    $('#footer-placeholder').load('footer.html');
});
